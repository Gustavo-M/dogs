import React from 'react';

const LoginPasswordReset = () => {
  return (
    <div>
      Resetar
    </div>
  );
};

export default LoginPasswordReset;