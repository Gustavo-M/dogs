import React from 'react';

const LoginPasswordLost = () => {
  return (
    <div>
      perdeu
    </div>
  );
};

export default LoginPasswordLost;